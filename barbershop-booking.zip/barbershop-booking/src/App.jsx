import BookingPage from './BookingPage'
import AdminPage from './AdminPage'

export default function App() {
  const isAdmin = window.location.pathname.replace(/\/+$/, '') === '/admin'
  return isAdmin ? <AdminPage /> : <BookingPage />
}
