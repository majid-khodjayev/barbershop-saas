export const SERVICES = [
  {
    id: 'haircut',
    name: 'Мужская стрижка',
    price: 50000,
    duration: '40 мин',
    description: 'Стрижка машинкой и ножницами, укладка.',
  },
  {
    id: 'beard',
    name: 'Борода',
    price: 30000,
    duration: '25 мин',
    description: 'Оформление и бритьё бороды, горячее полотенце.',
  },
  {
    id: 'haircut_beard',
    name: 'Стрижка + борода',
    price: 70000,
    duration: '60 мин',
    description: 'Полный комплекс: стрижка и оформление бороды.',
  },
]

export function formatPrice(price) {
  return price.toLocaleString('ru-RU').replace(/,/g, ' ') + ' сум'
}

// Рабочие часы барбершопа: с 09:00 до 20:00, слоты по 30 минут
export function generateTimeSlots() {
  const slots = []
  const startHour = 9
  const endHour = 20
  for (let hour = startHour; hour < endHour; hour++) {
    slots.push(`${String(hour).padStart(2, '0')}:00`)
    slots.push(`${String(hour).padStart(2, '0')}:30`)
  }
  return slots
}

// Список из 14 дат начиная с сегодняшнего дня
export function generateAvailableDates(daysAhead = 14) {
  const dates = []
  const today = new Date()
  for (let i = 0; i < daysAhead; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    dates.push(d)
  }
  return dates
}

const WEEKDAYS_SHORT = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб']
const MONTHS = [
  'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
  'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
]

export function toDateKey(date) {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

export function formatDateShort(date) {
  return `${date.getDate()} ${MONTHS[date.getMonth()].slice(0, 3)}`
}

export function formatDateWeekday(date) {
  return WEEKDAYS_SHORT[date.getDay()]
}

export function formatDateLong(dateKey) {
  const [y, m, d] = dateKey.split('-').map(Number)
  const date = new Date(y, m - 1, d)
  return `${date.getDate()} ${MONTHS[date.getMonth()]}`
}
