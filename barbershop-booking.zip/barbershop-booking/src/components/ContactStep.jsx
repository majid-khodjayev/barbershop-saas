export default function ContactStep({ name, phone, onChangeName, onChangePhone }) {
  return (
    <div className="step">
      <h2 className="step__title">3. Ваши данные</h2>
      <div className="form-row">
        <label className="field">
          <span className="field__label">Имя</span>
          <input
            type="text"
            className="field__input"
            placeholder="Как к вам обращаться"
            value={name}
            onChange={(e) => onChangeName(e.target.value)}
          />
        </label>
        <label className="field">
          <span className="field__label">Телефон</span>
          <input
            type="tel"
            className="field__input"
            placeholder="+998 90 123 45 67"
            value={phone}
            onChange={(e) => onChangePhone(e.target.value)}
          />
        </label>
      </div>
    </div>
  )
}
