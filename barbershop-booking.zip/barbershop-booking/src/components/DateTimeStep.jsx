import { useMemo } from 'react'
import {
  generateAvailableDates,
  generateTimeSlots,
  toDateKey,
  formatDateShort,
  formatDateWeekday,
} from '../constants'
import { getBookedTimesForDate } from '../storage'

export default function DateTimeStep({
  selectedDate,
  selectedTime,
  onSelectDate,
  onSelectTime,
  bookingsVersion,
}) {
  const dates = useMemo(() => generateAvailableDates(14), [])
  const allSlots = useMemo(() => generateTimeSlots(), [])

  const bookedTimes = useMemo(() => {
    if (!selectedDate) return []
    // bookingsVersion пересчитывает занятые слоты после каждой новой записи
    return getBookedTimesForDate(selectedDate)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate, bookingsVersion])

  return (
    <div className="step">
      <h2 className="step__title">2. Выберите дату и время</h2>

      <div className="date-scroller">
        {dates.map((date) => {
          const key = toDateKey(date)
          const isActive = key === selectedDate
          return (
            <button
              key={key}
              type="button"
              className={'date-pill' + (isActive ? ' date-pill--active' : '')}
              onClick={() => onSelectDate(key)}
            >
              <span className="date-pill__weekday">{formatDateWeekday(date)}</span>
              <span className="date-pill__day">{formatDateShort(date)}</span>
            </button>
          )
        })}
      </div>

      {selectedDate ? (
        <div className="time-grid">
          {allSlots.map((slot) => {
            const isBooked = bookedTimes.includes(slot)
            const isActive = slot === selectedTime
            return (
              <button
                key={slot}
                type="button"
                disabled={isBooked}
                className={
                  'time-slot' +
                  (isActive ? ' time-slot--active' : '') +
                  (isBooked ? ' time-slot--booked' : '')
                }
                onClick={() => onSelectTime(slot)}
              >
                {slot}
              </button>
            )
          })}
        </div>
      ) : (
        <p className="step__hint">Сначала выберите день</p>
      )}
    </div>
  )
}
