import { formatPrice, formatDateLong } from '../constants'

export default function SuccessScreen({ booking, onNewBooking }) {
  return (
    <div className="success">
      <div className="success__icon" aria-hidden="true">
        <svg viewBox="0 0 48 48" width="48" height="48">
          <circle cx="24" cy="24" r="23" fill="none" stroke="currentColor" strokeWidth="2" />
          <path
            d="M14 24.5l7 7 13-14"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <h2 className="success__title">Вы успешно записаны</h2>
      <p className="success__text">Ждём вас в барбершопе «Клинок»</p>

      <dl className="success__details">
        <div className="success__row">
          <dt>Услуга</dt>
          <dd>{booking.serviceName}</dd>
        </div>
        <div className="success__row">
          <dt>Дата и время</dt>
          <dd>
            {formatDateLong(booking.date)}, {booking.time}
          </dd>
        </div>
        <div className="success__row">
          <dt>Стоимость</dt>
          <dd>{formatPrice(booking.price)}</dd>
        </div>
        <div className="success__row">
          <dt>Имя</dt>
          <dd>{booking.name}</dd>
        </div>
        <div className="success__row">
          <dt>Телефон</dt>
          <dd>{booking.phone}</dd>
        </div>
      </dl>

      <button type="button" className="btn btn--ghost" onClick={onNewBooking}>
        Записаться ещё раз
      </button>
    </div>
  )
}
