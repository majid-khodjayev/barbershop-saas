import { SERVICES, formatPrice } from '../constants'

export default function ServiceStep({ selectedService, onSelect }) {
  return (
    <div className="step">
      <h2 className="step__title">1. Выберите услугу</h2>
      <div className="service-list">
        {SERVICES.map((service) => (
          <button
            key={service.id}
            type="button"
            className={
              'service-card' +
              (selectedService?.id === service.id ? ' service-card--active' : '')
            }
            onClick={() => onSelect(service)}
          >
            <span className="service-card__name">{service.name}</span>
            <span className="service-card__meta">{service.description}</span>
            <span className="service-card__bottom">
              <span className="service-card__duration">{service.duration}</span>
              <span className="service-card__price">{formatPrice(service.price)}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}
