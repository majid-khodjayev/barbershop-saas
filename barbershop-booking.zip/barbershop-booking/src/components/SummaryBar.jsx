import { formatPrice, formatDateLong } from '../constants'

export default function SummaryBar({ service, date, time, name, phone, onSubmit }) {
  const isComplete = Boolean(service && date && time && name.trim() && phone.trim())

  return (
    <div className="summary-bar">
      <div className="summary-bar__details">
        {service ? (
          <>
            <span className="summary-bar__service">{service.name}</span>
            <span className="summary-bar__meta">
              {date ? formatDateLong(date) : 'дата не выбрана'}
              {time ? `, ${time}` : ''}
            </span>
          </>
        ) : (
          <span className="summary-bar__meta">Выберите услугу, дату и время</span>
        )}
      </div>
      <div className="summary-bar__action">
        {service && <span className="summary-bar__price">{formatPrice(service.price)}</span>}
        <button
          type="button"
          className="btn btn--primary"
          disabled={!isComplete}
          onClick={onSubmit}
        >
          Записаться
        </button>
      </div>
    </div>
  )
}
