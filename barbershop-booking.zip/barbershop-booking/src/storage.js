const STORAGE_KEY = 'barbershop_bookings'

// Считываем все записи из localStorage
export function getBookings() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : []
  } catch (e) {
    console.error('Не удалось прочитать записи из localStorage', e)
    return []
  }
}

// Сохраняем весь список записей
function saveBookings(bookings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(bookings))
}

// Добавляем новую запись, возвращаем её вместе с id
export function addBooking(booking) {
  const bookings = getBookings()
  const newBooking = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    createdAt: new Date().toISOString(),
    ...booking,
  }
  bookings.push(newBooking)
  saveBookings(bookings)
  return newBooking
}

// Удаляем запись по id
export function removeBooking(id) {
  const bookings = getBookings().filter((b) => b.id !== id)
  saveBookings(bookings)
  return bookings
}

// Список занятых времён на конкретную дату
export function getBookedTimesForDate(date) {
  return getBookings()
    .filter((b) => b.date === date)
    .map((b) => b.time)
}
