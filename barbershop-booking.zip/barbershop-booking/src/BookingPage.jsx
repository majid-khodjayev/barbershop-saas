import { useState } from 'react'
import ServiceStep from './components/ServiceStep'
import DateTimeStep from './components/DateTimeStep'
import ContactStep from './components/ContactStep'
import SummaryBar from './components/SummaryBar'
import SuccessScreen from './components/SuccessScreen'
import { addBooking, getBookedTimesForDate } from './storage'

export default function BookingPage() {
  const [service, setService] = useState(null)
  const [date, setDate] = useState(null)
  const [time, setTime] = useState(null)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [error, setError] = useState('')
  const [completedBooking, setCompletedBooking] = useState(null)
  const [bookingsVersion, setBookingsVersion] = useState(0)

  function handleSelectDate(newDate) {
    setDate(newDate)
    setTime(null)
  }

  function handleSubmit() {
    setError('')

    if (!service || !date || !time || !name.trim() || !phone.trim()) {
      setError('Заполните все поля: услугу, дату, время, имя и телефон.')
      return
    }

    // Проверяем, что слот всё ещё свободен (на случай двух вкладок браузера)
    const stillFree = !getBookedTimesForDate(date).includes(time)
    if (!stillFree) {
      setError('Это время уже заняли, пока вы оформляли запись. Выберите другое.')
      setTime(null)
      return
    }

    const booking = addBooking({
      serviceId: service.id,
      serviceName: service.name,
      price: service.price,
      date,
      time,
      name: name.trim(),
      phone: phone.trim(),
    })

    setCompletedBooking(booking)
    setBookingsVersion((v) => v + 1)
  }

  function handleNewBooking() {
    setService(null)
    setDate(null)
    setTime(null)
    setName('')
    setPhone('')
    setError('')
    setCompletedBooking(null)
  }

  if (completedBooking) {
    return (
      <div className="page">
        <Header />
        <main className="container container--narrow">
          <SuccessScreen booking={completedBooking} onNewBooking={handleNewBooking} />
        </main>
      </div>
    )
  }

  return (
    <div className="page">
      <Header />
      <main className="container">
        <div className="steps">
          <ServiceStep selectedService={service} onSelect={setService} />
          <DateTimeStep
            selectedDate={date}
            selectedTime={time}
            onSelectDate={handleSelectDate}
            onSelectTime={setTime}
            bookingsVersion={bookingsVersion}
          />
          <ContactStep
            name={name}
            phone={phone}
            onChangeName={setName}
            onChangePhone={setPhone}
          />
        </div>
        {error && <p className="form-error">{error}</p>}
      </main>
      <SummaryBar
        service={service}
        date={date}
        time={time}
        name={name}
        phone={phone}
        onSubmit={handleSubmit}
      />
    </div>
  )
}

function Header() {
  return (
    <header className="header">
      <div className="container header__inner">
        <span className="header__mark">Клинок</span>
        <span className="header__tagline">барбершоп · онлайн-запись</span>
      </div>
    </header>
  )
}
