import { useEffect, useState } from 'react'
import { getBookings, removeBooking } from './storage'
import { formatPrice, formatDateLong } from './constants'

export default function AdminPage() {
  const [bookings, setBookings] = useState([])

  useEffect(() => {
    setBookings(getBookings())
  }, [])

  function handleDelete(id) {
    const updated = removeBooking(id)
    setBookings(updated)
  }

  const sorted = [...bookings].sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1
    return a.time < b.time ? -1 : 1
  })

  return (
    <div className="page">
      <header className="header">
        <div className="container header__inner">
          <span className="header__mark">Клинок</span>
          <span className="header__tagline">админ-панель</span>
        </div>
      </header>

      <main className="container container--wide">
        <h1 className="admin-title">Записи клиентов</h1>

        {sorted.length === 0 ? (
          <p className="step__hint">Пока нет ни одной записи.</p>
        ) : (
          <>
            <div className="admin-table admin-table--head" aria-hidden="true">
              <span>Клиент</span>
              <span>Телефон</span>
              <span>Услуга</span>
              <span>Дата</span>
              <span>Время</span>
              <span></span>
            </div>
            <ul className="admin-list">
              {sorted.map((b) => (
                <li className="admin-table admin-row" key={b.id}>
                  <span data-label="Клиент">{b.name}</span>
                  <span data-label="Телефон">{b.phone}</span>
                  <span data-label="Услуга">
                    {b.serviceName}
                    <span className="admin-row__price"> · {formatPrice(b.price)}</span>
                  </span>
                  <span data-label="Дата">{formatDateLong(b.date)}</span>
                  <span data-label="Время">{b.time}</span>
                  <span className="admin-row__actions">
                    <button
                      type="button"
                      className="btn btn--danger"
                      onClick={() => handleDelete(b.id)}
                    >
                      Удалить
                    </button>
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}
      </main>
    </div>
  )
}
